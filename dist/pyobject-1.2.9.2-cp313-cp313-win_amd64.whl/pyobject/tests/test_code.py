import pyobject.code as code
import doctest
doctest.testmod(m=code)
print("Test done")