本文件夹实现了一些对Python对象的测试程序，以及一套pyc文件的压缩和脱壳工具链，并存放了`browser.py`原先的中文本地化版本`browser_chs_locale.py`。  
完整的pyc文件加壳工具pyc-zipper工具参见：[github.com/qfcy/pyc-zipper](https://github.com/qfcy/pyc-zipper)  

---

This folder implements several test programs for Python objects, as well as a toolchain for compressing and unpacking a set of pyc files. It also contains the original Chinese localized version of `browser.py`, named `browser_chs_locale.py`.  
For the complete pyc file packing tool, refer to: [github.com/qfcy/pyc-zipper](https://github.com/qfcy/pyc-zipper).  